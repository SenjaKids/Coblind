//
//  WhatView.swift
//  coblind
//
//  Created by Alfine on 14/04/23.
//

import SwiftUI

struct WhatView: View {
    @State var count = 1
    var body: some View {
        NavigationView {
            VStack{
                Text(count == 1 ? "What is “Color Blind”?" : "How it happen?")
                    .font(.system(size: 54))
                    .fontWeight(.semibold)
                    .kerning(1)
                    .foregroundColor(.black)
                    .padding(.bottom, 50)
                ZStack {
                    if count == 1 {
                        Text("Color blindness, also known as color vision deficiency, is a condition in which an individual has difficulty distinguishing certain colors.")
                            .font(.system(size: 24))
                            .fontWeight(.light)
                            .foregroundColor(Color(hex: 0x000000, opacity: 0.5))
                            .frame(width: 490)
                            .multilineTextAlignment(.center)
                            .padding(.vertical, 60)
                            .padding(.horizontal, 40)
                            .background(Color(hex: 0xEEEEEE))
                            .cornerRadius(20)
                    } else if count == 2 {
                        Group{
                            Text("This condition is typically caused by genetic mutations that affect the functioning of the light-sensitive cells in the retina of the eye, known as ").fontWeight(.light) +
                            Text("cones.").fontWeight(.medium)
                        }
                        .font(.system(size: 24))
                        .foregroundColor(Color(hex: 0x000000, opacity: 0.5))
                        .frame(width: 486)
                        .multilineTextAlignment(.center)
                        .padding(.vertical, 60)
                        .padding(.horizontal, 40)
                        .background(Color(hex: 0xEEEEEE))
                        .cornerRadius(20)
                    } else {
                        Text("There are three main types of cones that are responsible for detecting different colors: red, green, and blue. When one or more of these cones are affected, it can result in different types of color blindness.")
                            .font(.system(size: 24))
                            .fontWeight(.light)
                            .foregroundColor(Color(hex: 0x000000, opacity: 0.5))
                            .frame(width: 483)
                            .multilineTextAlignment(.center)
                            .padding(.vertical, 50)
                            .padding(.horizontal, 40)
                            .background(Color(hex: 0xEEEEEE))
                            .cornerRadius(20)
                    }
                    
                    VStack{
                        HStack{
                            Image(count == 1 ? "memoji1" : "memoji3")
                            Spacer()
                        }
                        Spacer()
                        HStack{
                            Spacer()
                            Image(count == 1 ? "memoji2" : "memoji4")
                        }
                    }
                    .frame(width: 661, height: 344)
                }
                
                if count > 2{
                    NavigationLink {
                        TypeView()
                    } label: {
                        HStack{
                            Text("Next")
                                .font(.system(size: 18))
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                            Image(systemName: "chevron.right")
                                .font(.system(size: 14))
                                .foregroundColor(.white)
                                .opacity(0.5)
                            Image(systemName: "chevron.right")
                                .font(.system(size: 14))
                                .foregroundColor(.white)
                                .padding(.leading, -8)
                        }
                        .frame(width: 186, height: 57, alignment: .center)
                        .background(LinearGradient(colors: [Color(hex: 0x6236FF), Color(hex: 0x9763FF)], startPoint: .leading, endPoint: .bottomTrailing))
                        .cornerRadius(100)
                        .padding()
                    }
                    .padding(.top, 70)
                }else {
                    Button {
                        count += 1
                    } label: {
                        HStack{
                            Text("Next")
                                .font(.system(size: 18))
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                            Image(systemName: "chevron.right")
                                .font(.system(size: 14))
                                .foregroundColor(.white)
                                .opacity(0.5)
                            Image(systemName: "chevron.right")
                                .font(.system(size: 14))
                                .foregroundColor(.white)
                                .padding(.leading, -8)
                        }
                        .frame(width: 186, height: 57, alignment: .center)
                        .background(LinearGradient(colors: [Color(hex: 0x6236FF), Color(hex: 0x9763FF)], startPoint: .leading, endPoint: .bottomTrailing))
                        .cornerRadius(100)
                        .padding()
                    }
                    .padding(.top, 70)
                }
                
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(.white)
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
    }
}

struct WhatView_Previews: PreviewProvider {
    static var previews: some View {
        WhatView()
    }
}
