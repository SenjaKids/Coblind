import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack {
                Spacer()
                Group{
                    Text("C")
                        .foregroundColor(Color(hex: 0xE02020))
                        .fontWeight(.semibold)
                        .tracking(2) +
                    Text("O")
                        .foregroundColor(Color(hex: 0xFA6400))
                        .fontWeight(.semibold)
                        .tracking(2) +
                    Text("B")
                        .foregroundColor(Color(hex: 0xF7B500))
                        .fontWeight(.semibold)
                        .tracking(2) +
                    Text("L")
                        .foregroundColor(Color(hex: 0x44D7B6))
                        .fontWeight(.semibold)
                        .tracking(2) +
                    Text("I")
                        .foregroundColor(Color(hex: 0x32C5FF))
                        .fontWeight(.semibold)
                        .tracking(2)  +
                    Text("N")
                        .foregroundColor(Color(hex: 0x0091FF))
                        .fontWeight(.semibold)
                        .tracking(2) +
                    Text("D")
                        .foregroundColor(Color(hex: 0x6236FF))
                        .fontWeight(.semibold)
                        .tracking(2)
                }
                .font(.system(size: 92))
                .padding(.top, 100)
                Text("Understanding what color blind people experience")
                    .font(.system(size: 24))
                    .fontWeight(.medium)
                    .foregroundColor(Color(hex: 0x6D7278))
                NavigationLink {
                    WhatView()
                } label: {
                    Image("playButton")
                }
                .padding(.top, 100)
                Spacer()
                Spacer()
                Spacer()
                Text("Tap Play Button to start")
                    .foregroundColor(Color(hex: 0x6D7278))
                    .font(.system(size: 18))
                    .fontWeight(.light)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(
                Image("background")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            )
        }
        .navigationViewStyle(.stack)
        .preferredColorScheme(.light)
        .onAppear {
//            audioPlayer?.play()
        }
    }

}

extension Color {
    init(hex: Int, opacity: Double = 1.0) {
        let red = Double((hex & 0xff0000) >> 16) / 255.0
        let green = Double((hex & 0xff00) >> 8) / 255.0
        let blue = Double((hex & 0xff) >> 0) / 255.0
        self.init(.sRGB, red: red, green: green, blue: blue, opacity: opacity)
    }
}
