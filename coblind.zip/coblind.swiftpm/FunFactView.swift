//
//  FunFactView.swift
//  coblind
//
//  Created by Alfine on 18/04/23.
//

import SwiftUI


let factArr = [
    "Colorblind individuals may have difficulty distinguishing between colors like red and green, blue and purple, or yellow and orange.",
    "Color blindness is not actually a form of blindness; it's a condition that affects a person's ability to perceive colors accurately.",
    "The most common type of color blindness is red-green color blindness, which affects the ability to distinguish between red and green colors.",
    "Color blindness is often caused by a genetic mutation that affects the photopigments in the retina of the eye.",
    "Approximately 1 in 12 men and 1 in 200 women of Northern European descent have some form of color blindness.",
    "Dogs and cats can also be colorblind, although their specific type of color blindness may differ from that of humans.",
    "Colorblindness can sometimes be detected in early childhood through simple color vision tests using color plates or charts.",
    "Many traffic lights use specific color combinations and positions to accommodate colorblind individuals, with red always on top and green always on the bottom.",
    "Colorblind individuals may use other cues, such as brightness, contrast, and object shapes, to identify and distinguish colors.",
    "Some colorblind individuals may have enhanced abilities in other areas, such as better night vision or improved ability to detect camouflage.",
    "Colorblindness is not a disease and does not typically require treatment unless it significantly affects a person's daily life.",
    "Colorblind individuals can still appreciate and enjoy the beauty of nature, even if they perceive colors differently.",
    "There are different types and degrees of color blindness, ranging from mild to severe.",
    "Colorblind individuals can lead normal, fulfilling lives and can excel in various fields, including art, science, sports, and technology."]

struct FunFactView: View {
    @State var randFact: String = factArr.randomElement()!
    
    var body: some View {
        NavigationView{
            VStack{
                Text("Color Blind")
                    .font(.system(size: 54))
                    .fontWeight(.semibold)
                    .kerning(1)
                    .foregroundColor(.black)
                    .padding(.bottom, 70)
                
                Text("Fun Fact")
                    .font(.system(size: 28))
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .padding(.vertical, 11)
                    .frame(maxWidth: 260)
                    .background(Color(hex: 0x44D7B6))
                    .cornerRadius(100)
                    .padding(.bottom, -35)
                    .zIndex(2)
                
                Text(randFact)
                    .font(.system(size: 24))
                    .fontWeight(.light)
                    .foregroundColor(Color(hex: 0x000000, opacity: 0.5))
                    .frame(width: 526)
                    .multilineTextAlignment(.center)
                    .padding(.vertical, 60)
                    .padding(.horizontal, 40)
                    .background(Color(hex: 0xEEEEEE))
                    .cornerRadius(20)
                HStack{
                    Button {
                        randFact = factArr.randomElement()!
                    } label: {
                        HStack{
                            Text("Generate Fact")
                                .font(.system(size: 18))
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                        }
                        .frame(width: 186, height: 57, alignment: .center)
                        .background(LinearGradient(colors: [Color(hex: 0xFF3636), Color(hex: 0xFF6666)], startPoint: .leading, endPoint: .bottomTrailing))
                        .cornerRadius(100)
                        .padding()
                    }
                    
                }
                .padding(.top, 70)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(.white)
        }
        .navigationViewStyle(.stack)
    }
}

struct FunFactView_Previews: PreviewProvider {
    static var previews: some View {
        TypeView()
    }
}
