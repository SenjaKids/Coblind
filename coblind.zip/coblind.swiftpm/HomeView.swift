//
//  HomeView.swift
//  coblind
//
//  Created by Alfine on 15/04/23.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationView {
            VStack {
                Spacer()
                Group{
                    Text("C")
                        .foregroundColor(Color(hex: 0xE02020))
                        .fontWeight(.semibold)
                        .tracking(2) +
                    Text("O")
                        .foregroundColor(Color(hex: 0xFA6400))
                        .fontWeight(.semibold)
                        .tracking(2) +
                    Text("B")
                        .foregroundColor(Color(hex: 0xF7B500))
                        .fontWeight(.semibold)
                        .tracking(2) +
                    Text("L")
                        .foregroundColor(Color(hex: 0x44D7B6))
                        .fontWeight(.semibold)
                        .tracking(2) +
                    Text("I")
                        .foregroundColor(Color(hex: 0x32C5FF))
                        .fontWeight(.semibold)
                        .tracking(2)  +
                    Text("N")
                        .foregroundColor(Color(hex: 0x0091FF))
                        .fontWeight(.semibold)
                        .tracking(2) +
                    Text("D")
                        .foregroundColor(Color(hex: 0x6236FF))
                        .fontWeight(.semibold)
                        .tracking(2)
                }
//                .font(Font.custom("Rubik-Medium", size: 92, weight: .medium))
                .font(.system(size: 92))
                .padding(.top, 100)
                Text("Understanding what color blind people experience")
                    .font(.system(size: 24))
                    .fontWeight(.medium)
                    .foregroundColor(Color(hex: 0x6D7278))
                    .padding(.bottom, 80)
                HStack(spacing: 20){
                    NavigationLink {
                        ProtonopiaView()
                    } label: {
                        VStack(alignment: .leading, spacing: 5){
                            Spacer()
                            Text("🍎")
                                .font(.system(size: 55))
                                .padding(.leading, 20)
                            Text("Protanopia")
                                .font(.system(size: 18))
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                                .padding(.leading, 20)
                                .padding(.bottom, 20)
                        }
                        .frame(width: 206, height: 130, alignment: .leading)
                        .background(LinearGradient(colors: [Color(hex: 0x6236FF), Color(hex: 0x9763FF)], startPoint: .leading, endPoint: .bottomTrailing))
                        .cornerRadius(28.5)
                    }
                    NavigationLink {
                        DeuteranopiaView()
                    } label: {
                        VStack(alignment: .leading, spacing: 5){
                            Spacer()
                            Text("🍀")
                                .font(.system(size: 55))
                                .padding(.leading, 20)
                            Text("Deuteranopia")
                                .font(.system(size: 18))
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                                .padding(.leading, 20)
                                .padding(.bottom, 20)
                        }
                        .frame(width: 206, height: 130, alignment: .leading)
                        .background(LinearGradient(colors: [Color(hex: 0x6236FF), Color(hex: 0x9763FF)], startPoint: .leading, endPoint: .bottomTrailing))
                        .cornerRadius(28.5)
                    }
                    NavigationLink {
                        TritanopiaView()
                    } label: {
                        VStack(alignment: .leading, spacing: 5){
                            Spacer()
                            Text("🐳")
                                .font(.system(size: 55))
                                .padding(.leading, 20)
                            Text("Tritanopia")
                                .font(.system(size: 18))
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                                .padding(.leading, 20)
                                .padding(.bottom, 20)
                        }
                        .frame(width: 206, height: 130, alignment: .leading)
                        .background(LinearGradient(colors: [Color(hex: 0x6236FF), Color(hex: 0x9763FF)], startPoint: .leading, endPoint: .bottomTrailing))
                        .cornerRadius(28.5)
                    }
                }
                .padding(.bottom, 20)
                
                NavigationLink {
                    SimulatorView()
                } label: {
                    Text("Simulate All")
                        .font(.system(size: 18))
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                        .frame(width: 660, height: 57, alignment: .center)
                        .background(LinearGradient(colors: [Color(hex: 0x6236FF), Color(hex: 0x9763FF)], startPoint: .leading, endPoint: .bottomTrailing))
                        .cornerRadius(100)
                }
                .padding(.bottom, 70)
                
                HStack(spacing: 20){
                    NavigationLink {
                        WhatView()
                    } label: {
                        ZStack(alignment: .topLeading){
                            Text("Read Again")
                                .font(.system(size: 18))
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                                .frame(width: 320, height: 57, alignment: .center)
                                .background(LinearGradient(colors: [Color(hex: 0x757575), Color(hex: 0xA9A9A9)], startPoint: .leading, endPoint: .bottomTrailing))
                                .cornerRadius(100)
                            Image("memoji5")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 67)
                                .padding(.top, -35)
                                .padding(.leading, 35)
                        }
                        
                    }
                    NavigationLink {
                        FunFactView()
                    } label: {
                        ZStack(alignment: .topTrailing){
                            Text("Fun Fact")
                                .font(.system(size: 18))
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                                .frame(width: 320, height: 57, alignment: .center)
                                .background(LinearGradient(colors: [Color(hex: 0xFF3636), Color(hex: 0xFF6E6E)], startPoint: .leading, endPoint: .bottomTrailing))
                                .cornerRadius(100)
                            Image("memoji6")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 67)
                                .padding(.top, -35)
                                .padding(.trailing, 35)
                        }
                    }
                }
                .padding(.bottom, 200)
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(
                Image("background")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            )
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden()
        .preferredColorScheme(.light)
        .onAppear {
//            playSounds("Island_Fever.wav")
//            audioPlayer?.numberOfLoops = -1
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
