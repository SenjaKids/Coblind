//
//  TypeView.swift
//  coblind
//
//  Created by Alfine on 14/04/23.
//

import SwiftUI

struct TypeView: View {
    @State var index = 0
    func generateTitle() -> String {
        if index == 0 {
            return "Protonopia"
        }else if index == 1 {
            return "Deuteranopia"
        }else {
            return "Tritanopia"
        }
    }
    
    func generateDesc() -> String {
        if index == 0 {
            return "Protanopia is a type of color blindness in which the individual has a reduced ability to perceive red colors. The red cones in the retina are either absent or not functioning properly, resulting in a difficulty in distinguishing between red and green colors."
        }else if index == 1 {
            return "Deuteranopia is a type of color blindness in which the individual has a reduced ability to perceive green colors. The green cones in the retina are either absent or not functioning properly, resulting in a difficulty in distinguishing between red and green colors."
        }else {
            return "Tritanopia is a type of color blindness in which the individual has a reduced ability to perceive blue colors. The blue cones in the retina are either absent or not functioning properly, resulting in a difficulty in distinguishing between blue and yellow colors."
        }
    }
    
    var body: some View {
        NavigationView{
            VStack{
                Text("Type of Color Blind")
                    .font(.system(size: 54))
                    .fontWeight(.semibold)
                    .kerning(1)
                    .foregroundColor(.black)
                    .padding(.bottom, 70)
                
                Text(generateTitle())
                    .font(.system(size: 28))
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .padding(.vertical, 11)
                    .frame(maxWidth: 260)
                    .background(Color(hex: 0x44D7B6))
                    .cornerRadius(100)
                    .padding(.bottom, -35)
                    .zIndex(2)
                
                Text(generateDesc())
                    .font(.system(size: 24))
                    .fontWeight(.light)
                    .foregroundColor(Color(hex: 0x000000, opacity: 0.5))
                    .frame(width: 526)
                    .multilineTextAlignment(.center)
                    .padding(.vertical, 60)
                    .padding(.horizontal, 40)
                    .background(Color(hex: 0xEEEEEE))
                    .cornerRadius(20)
                HStack{
                    NavigationLink {
                        if index == 0 {
                            ProtonopiaView()
                        }else if index == 1 {
                            DeuteranopiaView()
                        }else {
                            TritanopiaView()
                        }
                    } label: {
                        HStack{
                            Text("Simulate")
                                .font(.system(size: 18))
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                        }
                        .frame(width: 186, height: 57, alignment: .center)
                        .background(LinearGradient(colors: [Color(hex: 0xFF3636), Color(hex: 0xFF6666)], startPoint: .leading, endPoint: .bottomTrailing))
                        .cornerRadius(100)
                        .padding()
                    }
                    
                    if index == 2 {
                        NavigationLink {
                            HomeView()
                        } label: {
                            HStack{
                                Text("Home")
                                    .font(.system(size: 18))
                                    .fontWeight(.medium)
                                    .foregroundColor(.white)
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 14))
                                    .foregroundColor(.white)
                                    .opacity(0.5)
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 14))
                                    .foregroundColor(.white)
                                    .padding(.leading, -8)
                            }
                            .frame(width: 186, height: 57, alignment: .center)
                            .background(LinearGradient(colors: [Color(hex: 0x6236FF), Color(hex: 0x9763FF)], startPoint: .leading, endPoint: .bottomTrailing))
                            .cornerRadius(100)
                            .padding()
                        }
                    }else {
                        Button {
                            index += 1
                        } label: {
                            HStack{
                                Text("Next")
                                    .font(.system(size: 18))
                                    .fontWeight(.medium)
                                    .foregroundColor(.white)
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 14))
                                    .foregroundColor(.white)
                                    .opacity(0.5)
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 14))
                                    .foregroundColor(.white)
                                    .padding(.leading, -8)
                            }
                            .frame(width: 186, height: 57, alignment: .center)
                            .background(LinearGradient(colors: [Color(hex: 0x6236FF), Color(hex: 0x9763FF)], startPoint: .leading, endPoint: .bottomTrailing))
                            .cornerRadius(100)
                            .padding()
                        }
                    }
                    
                }
                .padding(.top, 70)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(.white)
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
    }
}

struct TypeView_Previews: PreviewProvider {
    static var previews: some View {
        TypeView()
    }
}
