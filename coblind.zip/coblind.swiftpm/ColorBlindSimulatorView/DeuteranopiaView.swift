//
//  DeuteranopiaView.swift
//  coblind
//
//  Created by Alfine on 18/04/23.
//

import SwiftUI

struct DeuteranopiaView: View {
    @State private var redValue: Double = 150/255
    @State private var greenValue: Double = 30/255
    @State private var blueValue: Double = 30/255
    
    private func simulateDeuteranopia(red: Double, green: Double, blue: Double) -> Color {
        // Convert RGB values to LMS values
        let lmsRed = 0.436041 * red + 0.385113 * green + 0.143046 * blue
        let lmsGreen = 0.222485 * red + 0.716905 * green + 0.060610 * blue
        let lmsBlue = 0.013920 * red + 0.097067 * green + 0.714165 * blue

        // Convert LMS values to simulated deuteranopia values
        let simRed = 1.0803509 * lmsRed - 0.080564 * lmsGreen
        let simGreen = -0.019249 * lmsRed + 0.987215 * lmsGreen + 0.031933 * lmsBlue
        let simBlue = 0.00000 * lmsRed + 0.00000 * lmsGreen + 1.00000 * lmsBlue

        // Convert simulated deuteranopia values back to RGB values
        let red = 0.8000000 * simRed + 0.200000 * simGreen + 0.000000 * simBlue
        let green = 0.2581874 * simRed + 0.741812 * simGreen + 0.000000 * simBlue
        let blue = 0.0000000 * simRed + 0.000000 * simGreen + 1.000000 * simBlue

        return Color(red: red, green: green, blue: blue)
    }
    
    
    var body: some View {
        VStack (spacing: 50) {
            VStack{
                Text("Deuteranopia Simulator")
                    .font(.system(size: 54))
                    .fontWeight(.semibold)
                    .kerning(1)
                    .foregroundColor(.black)
                    .padding(.bottom, 3)
                Text("Use the slider below to set the \nRed, Green, and Blue value for the simulator")
                    .font(.system(size: 24))
                    .fontWeight(.light)
                    .foregroundColor(Color(hex: 0x6D7278))
                    .multilineTextAlignment(.center)
            }
            
            HStack {
                ZStack{
                    Rectangle()
                        .foregroundColor(Color(red: redValue, green: greenValue, blue: blueValue))
                        .frame(width: 200, height: 200)
                        .cornerRadius(20)
                        .padding()
                    Text("Normal")
                        .foregroundColor(Color(red: redValue, green: greenValue, blue: blueValue))
                        .colorInvert()
                        
                }
                
                ZStack{
                    Rectangle()
                        .foregroundColor(simulateDeuteranopia(red: redValue, green: greenValue, blue: blueValue))
                        .frame(width: 200, height: 200)
                        .cornerRadius(20)
                        .padding()
                    Text("Deuteranopia").foregroundColor(simulateDeuteranopia(red: redValue, green: greenValue, blue: blueValue))
                        .colorInvert()
                }
                
                
            }
            
            
            VStack(spacing: 20) {
                VStack(alignment: .leading, spacing: 5){
                    Text("Red")
                        .font(.system(size: 21))
                        .fontWeight(.medium)
                        .foregroundColor(.red)
                    Slider(value: $redValue, in: 0...1, label: { Text("Red") })
                        .accentColor(.red)
                }
                
                VStack(alignment: .leading, spacing: 5){
                    Text("Green")
                        .font(.system(size: 21))
                        .fontWeight(.medium)
                        .foregroundColor(.green)
                    Slider(value: $greenValue, in: 0...1, label: { Text("Green") })
                        .accentColor(.green)
                }
                
                VStack(alignment: .leading, spacing: 5){
                    Text("Blue")
                        .font(.system(size: 21))
                        .fontWeight(.medium)
                        .foregroundColor(.blue)
                    Slider(value: $blueValue, in: 0...1, label: { Text("Blue") })
                        .accentColor(.blue)
                }
                
            }
            .padding(.vertical, 30)
            .padding(.horizontal, 40)
            .frame(width: 600)
            .background(Color(hex: 0xEEEEEE))
            .cornerRadius(20)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.white)
    }
}
