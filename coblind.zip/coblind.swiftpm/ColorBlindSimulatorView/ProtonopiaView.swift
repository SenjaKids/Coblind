//
//  ProtonopiaView.swift
//  coblind
//
//  Created by Alfine on 17/04/23.
//

import SwiftUI

struct ProtonopiaView: View {
    @State private var redValue: Double = 150/255
    @State private var greenValue: Double = 30/255
    @State private var blueValue: Double = 30/255
    
    private func simulateProtanopia(red: Double, green: Double, blue: Double) -> Color {
        // Convert RGB values to LMS values
        let lmsRed = 0.38971 * red + 0.68898 * green - 0.07868 * blue
        let lmsGreen = -0.22981 * red + 1.18340 * green + 0.04641 * blue
        let lmsBlue = 0.00000 * red + 0.00000 * green + 1.00000 * blue
        
        // Convert LMS values to simulated protanopia values
        let simRed = 1.051182151 * lmsRed - 0.05116099 * lmsGreen
        let simGreen = -0.02854515 * lmsRed + 0.98372957 * lmsGreen + 0.04571512 * lmsBlue
        let simBlue = 0.00000 * lmsRed + 0.00000 * lmsGreen + 1.00000 * lmsBlue
        
        // Convert simulated protanopia values back to RGB values
        let red = 1.34579897 * simRed - 0.25594240 * simGreen
        let green = -0.54462254 * simRed + 1.50823289 * simGreen + 0.02023363 * simBlue
        let blue = 0.00000 * simRed + 0.00000 * simGreen + 1.00000 * simBlue
        
        return Color(red: red, green: green, blue: blue)
    }
    
    
    var body: some View {
        VStack (spacing: 50) {
            VStack{
                Text("Protanopia Simulator")
                    .font(.system(size: 54))
                    .fontWeight(.semibold)
                    .kerning(1)
                    .foregroundColor(.black)
                    .padding(.bottom, 3)
                Text("Use the slider below to set the \nRed, Green, and Blue value for the simulator")
                    .font(.system(size: 24))
                    .fontWeight(.light)
                    .foregroundColor(Color(hex: 0x6D7278))
                    .multilineTextAlignment(.center)
            }
            
            HStack {
                ZStack{
                    Rectangle()
                        .foregroundColor(Color(red: redValue, green: greenValue, blue: blueValue))
                        .frame(width: 200, height: 200)
                        .cornerRadius(20)
                        .padding()
                    Text("Normal")
                        .foregroundColor(Color(red: redValue, green: greenValue, blue: blueValue))
                        .colorInvert()
                        
                }
                
                ZStack{
                    Rectangle()
                        .foregroundColor(simulateProtanopia(red: redValue, green: greenValue, blue: blueValue))
                        .frame(width: 200, height: 200)
                        .cornerRadius(20)
                        .padding()
                    Text("Protanopia").foregroundColor(simulateProtanopia(red: redValue, green: greenValue, blue: blueValue))
                        .colorInvert()
                }
                
                
            }
            
            
            VStack(spacing: 20) {
                VStack(alignment: .leading, spacing: 5){
                    Text("Red")
                        .font(.system(size: 21))
                        .fontWeight(.medium)
                        .foregroundColor(.red)
                    Slider(value: $redValue, in: 0...1, label: { Text("Red") })
                        .accentColor(.red)
                }
                
                VStack(alignment: .leading, spacing: 5){
                    Text("Green")
                        .font(.system(size: 21))
                        .fontWeight(.medium)
                        .foregroundColor(.green)
                    Slider(value: $greenValue, in: 0...1, label: { Text("Green") })
                        .accentColor(.green)
                }
                
                VStack(alignment: .leading, spacing: 5){
                    Text("Blue")
                        .font(.system(size: 21))
                        .fontWeight(.medium)
                        .foregroundColor(.blue)
                    Slider(value: $blueValue, in: 0...1, label: { Text("Blue") })
                        .accentColor(.blue)
                }
                
            }
            .padding(.vertical, 30)
            .padding(.horizontal, 40)
            .frame(width: 600)
            .background(Color(hex: 0xEEEEEE))
            .cornerRadius(20)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.white)
    }
}
